# Práctica principios S.O.L.I.D.

Indique qué principio/s SOLID y/o buenas prácticas del desarrollo de software no se cumplen y modifique el programa para que sí los cumpla.
