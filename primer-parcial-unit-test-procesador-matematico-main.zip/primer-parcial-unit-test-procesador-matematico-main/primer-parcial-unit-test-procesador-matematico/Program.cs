﻿using System;

namespace primer_parcial_unit_test_procesador_matematico
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Hello World!");
        }
    }
}
