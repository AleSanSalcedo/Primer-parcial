# Práctica Pruebas Unitarias

Realizar las pruebas unitarias que considere importantes para comprobar el correcto funcionamiento de la entidad del dominio ProcesadorMatematico (siéntanse libres de modificar el código de la clase si así lo considera).
